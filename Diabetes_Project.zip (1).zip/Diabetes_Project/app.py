import streamlit as st
import pandas as pd
from sklearn.linear_model import LogisticRegression

# Load dataset
df = pd.read_csv("diabetes.csv")

# Features and target
X = df.drop("Outcome", axis=1)
y = df["Outcome"]

# Train model
model = LogisticRegression(max_iter=1000)
model.fit(X, y)

# Title
st.title("Diabetes Prediction")

# User inputs
preg = st.number_input("Pregnancies")
glu = st.number_input("Glucose")
bp = st.number_input("Blood Pressure")
skin = st.number_input("Skin Thickness")
ins = st.number_input("Insulin")
bmi = st.number_input("BMI")
dpf = st.number_input("Diabetes Pedigree Function")
age = st.number_input("Age")

# Prediction
if st.button("Predict"):

    data = pd.DataFrame(
        [[preg, glu, bp, skin, ins, bmi, dpf, age]],
        columns=X.columns
    )

    result = model.predict(data)

    if result[0] == 1:
        st.success("Diabetic")
    else:
        st.success("Not Diabetic")